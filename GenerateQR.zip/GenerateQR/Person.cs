﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GenerateQR
{
    class Person
    {
       public string fname = "";
       public string name = "";
       public string contact = "";
       public string about = "";

       public Person(string fname, string name, string contact, string about)
        {
            this.fname = fname;
            this.name = name;
            this.contact = contact;
            this.about = about;
        }
    }
}
