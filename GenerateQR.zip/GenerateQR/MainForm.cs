﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GenerateQR
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Update Barcode representation according to all fields and radio values 
        /// </summary>
        private void updatePreview()
        {
            Person p = new Person(textBox1.Text, textBox2.Text, textBox3.Text, richTextBox1.Text);
            if (radio_qr.Checked)
                preview.Image = Helper.encodeObj(p, 1);
            else
                preview.Image = Helper.encodeObj(p, 0);
        }

        /// <summary>
        /// Method handling event from all textBoxes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            updatePreview();
        }

        /// <summary>
        /// Method handling event from all radioButtons
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void radio_qr_CheckedChanged(object sender, EventArgs e)
        {
            updatePreview();
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Convert Simple Information to Bar Code representation\nBy Fety Faraniarijaona");
        }
    }
}
