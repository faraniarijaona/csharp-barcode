﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ZXing;
//from System.Web.Extensions
using System.Web.Script.Serialization;

namespace GenerateQR
{
    static class Helper
    {
        /// <summary>
        /// Convert an object to BarCode representation
        /// </summary>
        /// <param name="obj">Object to conrt</param>
        /// <param name="format">Output format of object</param>
        /// <returns>Image of the object when converted to Barcode</returns>
        public static System.Drawing.Image encodeObj(Object obj, int format)
        {
            IBarcodeWriter writer;
            if(format == 1)
                writer = new BarcodeWriter { Format = BarcodeFormat.QR_CODE };
            else
                writer = new BarcodeWriter { Format = BarcodeFormat.DATA_MATRIX };
            var result = writer.Write(serialize(obj));
            var barcodeBitmap = new System.Drawing.Bitmap(result);
            return barcodeBitmap;
        }

        /// <summary>
        /// Serialize object to json
        /// </summary>
        /// <param name="obj">Object</param>
        /// <returns>json string representation of the object</returns>
        public static string serialize(Object obj)
        {
            var jsonRepresentation = new JavaScriptSerializer().Serialize(obj);
            return jsonRepresentation;
        }
    }
}
